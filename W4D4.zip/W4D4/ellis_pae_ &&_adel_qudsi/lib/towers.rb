class TowersOfHanoi

    def initialize(num)
        @board = Array.new(3) { [] }
        @num = (1..num).to_a.reverse
        @board[0] << num
    end

    def move(start_pile, end_pile)
        end_pile << start_pile.pop
    end

    def prompt_turn
        puts "place a stack from 1 pile to another from 0 to 2 split on a comma"
        answer = gets.chomp.split(',').map(&:to_i)
        move(answer[0], answer[1])
    end


    def valid_move?
        
    end
end