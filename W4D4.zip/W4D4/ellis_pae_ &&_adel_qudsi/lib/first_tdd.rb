def my_uniq(array) 
    uniques = []
    array.each do |ele|
        uniques << ele if uniques.none?(ele)
    end
    uniques
end



class Array

    def two_sum
        indices = []

        (0...self.length).each do |i|
            (i+1...self.length).each do |j|
                indices << [i, j] if self[i] + self[j] == 0
            end
        end
        indices
    end

end


def my_transpose(arr)
    transposed = []

    (0...arr.length).each do |row|
        temp_arr = []
        (0...arr.length).each do |col|
            temp_arr << arr[col][row]
        end
        transposed << temp_arr
    end
    transposed
end


def pick_stock(prices)
    current_price = 0
    best_day = []
    (0...prices.length-1).each do |i|
        (i+1...prices.length).each do |j|
            if prices[j] - prices[i] > current_price
                current_price = prices[j] - prices[i]
                best_day = i, j
            end
        end
    end
    best_day
end