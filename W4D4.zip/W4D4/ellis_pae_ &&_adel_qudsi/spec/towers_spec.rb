require "towers_spec"

describe TowersofHanoi do
    describe "#initlize" do
        it "should accept num as an argument" do 

        end

        it "should have @board instance variable as an array length of 3, and array[0] length of num" do 

        end

        it "should return a stack in descending order " do

        end
    end



    describe "#"
end