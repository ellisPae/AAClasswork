require "first_tdd"

describe "my_uniq" do
    let(:arr1) {Array.new([ 5, 1, 2, 1, 4, 4, 5, 3, 3])}
    let(:uniq_arr) { my_uniq(arr1) }

    it "should return unique elements from the array" do
        uniq_arr.each do |ele|
            expect(uniq_arr.count(ele)).to eq(1)
        end
    end

    it "should return elements in the same order as they appear" do
        expect(uniq_arr).to eq([5, 1, 2, 4, 3])
    end
end





describe Array do

    describe "#two_sum" do
        let(:arr1) {Array.new([-1, 0, 2, -2, 1])}
        let(:summed_arr) { arr1.two_sum }
        let(:arr2) { Array.new([2, 5, 1, 4, 0])}
        it "should return pairs of indices that sum to zero" do
            # summed_arr.each_with_index do |ele, i| 
            expect(summed_arr).to eq([[0,4], [2,3]])
        end

        it "should return pairs that are sorted " do 
            expect(summed_arr).to_not eq([[4,0], [3,2]])
        end

        it "should return an empty arr if no two indices sum to zero" do
            expect(arr2.two_sum).to be_empty
        end
    end
end


describe "my_transpose" do
    let(:arr) { [[0, 1, 2], [3, 4, 5], [6, 7, 8]] }

    it "should return a new matrix where the rows and columns are switched" do
        expect(my_transpose(arr)).to eq([[0, 3, 6], [1, 4, 7], [2, 5, 8]])
    end

    it "should not use the method Array#transpose" do
        expect(arr).not_to receive(:transpose) 
    end

end

describe "pick_stock" do
    let(:prices) { [40, 20, 85, 150, 10, 120, 91]}

    it "should return most profitable pair of days to buy and sell" do 
        expect(pick_stock(prices)).to eq([1,3])
    end

    it "should not sell before you buy " do 
        expect(prices).not_to include([4,3])
    end

end






