class Card

    CARD_VALUES = {
        two: 2,
        three: 3,
        four: 4,
        five: 5,
        six: 6,
        seven: 7,
        eight: 8,
        nine: 9,
        ten: 10,
        J: 11,
        Q: 12,
        K: 13,
        A: 14 || 1
    }
    
    CARD_SUITS = {
        spade: "♠",
        heart: "♥",
        diamond: "♦",
        clubs: "♣"
    }


    def initialize(value, suit)
        @value = value
        @suit = suit
    end

    def self.value
        CARD_VALUES[@value]
    end
    
    def self.suit
        CARD_SUITS[@suit]
    end

    # if hand1 > hand2 => hand1
    #     hand1.card.value > hand2.card.value



    attr_reader :value, :suit

end


