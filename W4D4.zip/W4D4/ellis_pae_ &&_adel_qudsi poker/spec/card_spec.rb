require "card"



describe Card do

    describe "#initialize" do
        subject(:card1) {Card.new(:J, :heart)} 
        
        it "should accept a @value instance var" do
            expect(card1.value).to eq(:J)
        end

        it "should accept @suit instance var" do
            expect(card1.suit).to eq(:heart)
        end

        context "When the card is invalid" do
            let(:card2) {Card.new(:one, :trapezoid)}
            
            it "should raise an error if @value is not valid" do
                # value_arr = CARD_VALUES.keys.none?(card2.value)
                    expect { card }. to raise_error
            end

            it "should raise an error if @suits is not valid" do
            end
        end


    end


    # describe "#suits" do







end