require_relative "./PolyTreeNode/lib/00_tree_node.rb"

class KnightPathFinder
    
    ALLOWED_STEPS = [
        [1, 2], [1, -2], [-1, 2],
        [-1, -2], [2, 1], [2, -1],
        [-2, 1], [-2, -1] 
    ]

    def self.valid_moves(possible_pos)
        valid_moves = []
        
        ALLOWED_STEPS.each do |distance|
            x, y = possible_pos
            q, r = distance
            next_move = [x + q,  y + r]

            valid_moves << next_move if next_move.none? { |num| num < 0 || num > 7}
        end

        valid_moves
    end


    attr_reader :st_pos


    def initialize(st_pos)
        @st_pos = PolyTreeNode.new(st_pos)
        @considered_positions = [@st_pos]

        build_move_tree
    end


    def new_move_positions(pos)
        unfiltered = KnightPathFinder.valid_moves(pos)
        filtered = unfiltered.reject { |move| @considered_positions.include?(move) }
        @considered_positions += filtered
        filtered
    end
    
    def build_move_tree
        queue = [@st_pos]
        
        until queue.empty?
            cur_node = queue.shift
            cur_pos = cur_node.value  
            self.new_move_positions(cur_pos).each do | next_move |        
                next_node = PolyTreeNode.new(next_move)
                cur_node.add_child(next_node)
                queue << next_node
            end
        end
    end    

    require "byebug"
    def find_path(end_pos)
        end_node = st_pos.dfs(end_pos)
        path = trace_path_back(end_node)
        path << end_pos
    end



    def trace_path_back(end_node)
        return [st_pos.value] if end_node.parent == @st_pos
    
        trace_path_back(end_node.parent) << end_node.parent.value 
    end

    
end








kpf = KnightPathFinder.new([0, 0])
p kpf.find_path([7, 6]) # => [[0, 0], [1, 2], [2, 4], [3, 6], [5, 5], [7, 6]]
p kpf.find_path([6, 2]) # => [[0, 0], [1, 2], [2, 0], [4, 1], [6, 2]]



