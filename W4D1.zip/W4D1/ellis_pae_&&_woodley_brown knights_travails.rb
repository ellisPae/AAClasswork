require_relative "./PolyTreeNode/lib/00_tree_node.rb"

class KnightPathFinder
    
    ALLOWED_STEPS = [
        [1, 2], [1, -2], [-1, 2],
        [-1, -2], [2, 1], [2, -1],
        [-2, 1], [-2, -1] 
    ]
    
    attr_reader :st_pos

    def self.valid_moves(possible_pos)
        valid_moves = []
        
        ALLOWED_STEPS.each do |distance|
            x, y = possible_pos
            q, r = distance
            next_move = [x + q,  y + r]

            valid_moves << next_move if next_move.none? { |num| num < 0 || num > 7}
        end

        valid_moves
    end


    def initialize(st_pos)
        @st_pos = PolyTreeNode.new(st_pos)
        @considered_positions = [@st_pos]
    end


    def new_move_positions(pos)
        unfiltered = KnightPathFinder.valid_moves(pos)
        filtered = unfiltered.reject { |move| @considered_positions.include?(move) }
        @considered_positions += filtered
        filtered
    end
    
    def build_move_tree
        queue = [@st_pos]
        
        until queue.empty?
            cur_node = queue.shift
            cur_pos = cur_node.value  
            self.new_move_positions(cur_pos).each do | next_move |        
                next_node = PolyTreeNode.new(next_move)
                cur_node.add_child(next_node)
                queue << next_node
            end
        end
    end    


end



test = KnightPathFinder.new([0,0])
test.build_move_tree
p test.st_pos




