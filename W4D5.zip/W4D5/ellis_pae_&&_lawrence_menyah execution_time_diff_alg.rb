




# Phase 1:

def my_min(list)
    
    i = 0
    while i < list.length - 1
        j = i + 1
        while j < list.length
            if list[i] < list[j]
                j += 1
            else
                break
            end
            return list[i] if j == list.length
        end 
        i += 1
    end     
end

# O(n^2)


# Phase 2
def my_min_2(list)
    min = list[0]
    list.each do |num|
        min = num if num < min
    end
    min
end
# O(n)

# list = [ 0, 3, 5, 4, -5, 10, 1, 90 ]
# p my_min_2(list)  # =>  -5



def subsets(list)
    subs = []

    i = 0
    while i < list.length
        j = 0
        while j < list.length
            subs << list[i..j]
            j += 1
        end
        i += 1
    end
    subs
end


def largest_contiguous_subsum(list)
    sub_arr = subsets(list)
    largest = 0
    sub_arr.each do |arr|
        sum = 0
        arr.each do |ele|
            sum += ele
        end
        largest = sum if sum >= largest
    end
    largest
end

# O(n^2) 

#Phase2

def largest_contiguous_subsum_2(list)
    current = list[0]
    largest = current

    (1...list.length).each do |i|
        largest = list[i] if list[i] > largest
        current += list[i] 
        largest = current if current > largest
    end
    largest
end

# O(n)

list = [-5, 3, -7]
p largest_contiguous_subsum_2(list) # => 8