require "byebug"
# PHASE 1
def factorial(length)
    return 0 if length == 0
    return 1 if length == 1
    length * factorial(length - 1)
end

# def first_anagram?(str1, str2)
#     anagrams = []   
#     amount = factorial(str1.length - 1)
#     word = ""
#     perm = 0
#     str1.each_char {|ele| word += ele}
#     j = 0 #p o s t
#         while j < word.length
#             i = 1
#             count = 0  
#             while count < amount
#                 debugger 
#                 str1[i], str1[i + 1] = str1[i + 1], str1[i]
#                 w = "" 
#                 str1.each_char {|e| w += e }     
#                 anagrams << w
#                 count += 1
#                 i += 1
#                 i = 1 if i == str1.length - 1  
#             end
#             j += 1
#             word[0], word[j] = word[j], word[0]
#             str1 = word
#         end
#     end
#     p amount
#     p anagrams
#     p anagrams.length
#     anagrams.include?(str2)
# end

def find_anagrams(str)
 
    return [str] if str.length <= 1
  
    searched = find_anagrams(str[1..-1])
    anagrams = []

    searched.each do |anagram|
        (0..anagram.length).each do |i|
            anagrams << anagram[0...i] + str[0] + anagram[i..-1]
        end
    end

    anagrams
end

def first_anagram?(str1, str2)
    find_anagrams(str1).include?(str2)
end
# O(n!)


# p first_anagram?("post", "sally")    #=> false
# p first_anagram?("elvis", "lives")    #=> true
# p first_anagram?("gizmo", "sally")    #=> false


#PHASE 2
def second_anagram?(str1, str2)
    str1.each_char.with_index do |char, idx|
        s2_idx = str2.index(char)
        if s2_idx
            str2[s2_idx] = ""
        else
            return false
        end
    end
    str2.length == 0
end

# O(n)

# p second_anagram?("post", "stop")    #=> true
# p second_anagram?("elvis", "lives")    #=> true
# p second_anagram?("gizmo", "sally")    #=> false




def merge_sort(arr)
    return arr if arr.length <= 1

    middle = arr.length / 2
    left = merge_sort(arr.take(middle))
    right = merge_sort(arr.drop(middle))

    merge(left, right)
end

def merge(left, right)
    merged = []

    until left.empty? || right.empty?
        if left.first < right.first
            merged << left.shift
        else
            merged << right.shift
        end
    end

    merged + left + right
end


def third_anagram?(str1, str2)
    arr1 = str1.chars
    arr2 = str2.chars

    merge_sort(arr1) == merge_sort(arr2)
end
# O(n log n)



p third_anagram?("post", "stop")    #=> true
p third_anagram?("elvis", "lives")    #=> true
p third_anagram?("gizmo", "sally")    #=> false