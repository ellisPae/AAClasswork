require_relative "pieces_call.rb"

class Board

    attr_reader :grid

    def populate
        # pos = [1,0]
        # add_piece(Pawn.new("white", self, pos),pos)
        (0..7).each do |i|
            (0..7).each do |j|
                pos = [i,j]
                if i == 1 
                    add_piece(Rook.new("white", self, pos),pos)
                end        
            end
        end
    end

    def add_piece(piece, pos)
        self[pos] = piece
    end 
    
    def initialize
        @grid = Array.new(8) {Array.new(8)}
        # populate
    end 

    def [](pos)
        row, col = pos
        @grid[row][col]
    end

    def []=(pos, val)
        row, col = pos
        @grid[row][col] = val
    end

    def move_piece(color, start_pos, end_pos)
       raise "not a valid move" if !valid_pos?(start_pos, end_pos)
        piece = self[start_pos]
        self[start_pos] = NullPiece.new("transparent", self, start_pos)
        self[end_pos] = piece
    end

    def valid_pos?(start_pos, end_pos)
        return false if self[start_pos].valid_moves.none?(end_pos)
        row, col = pos
        return false if row < 0 || row > 7
        return false if col < 0 || col > 7
        true
    end
    
end



game = Board.new
game.populate
pos = [1,0]
end_pos = [3,0]
# rando = [4,0]
game.move_piece("white", pos, end_pos )
p game[end_pos].color
puts "------------"
p game[pos].color
puts "------------"


