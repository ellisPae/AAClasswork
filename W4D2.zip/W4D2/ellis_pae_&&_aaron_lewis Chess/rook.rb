require_relative "piece.rb"
require_relative "slideable_module.rb"

class Rook < Piece

    include Slideable

    attr_reader :color, :board, :pos

    def initialize(color, board, pos)
        super
    end

    def move
       move_hv
    end



end
