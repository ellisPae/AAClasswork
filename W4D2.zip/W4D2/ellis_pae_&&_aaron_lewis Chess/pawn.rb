require_relative "piece.rb"

class Pawn < Piece

    attr_reader :color, :pos

    def initialize(color, board, pos)
        super
    end


    def move
   
        
    end



    private

    def at_start_row?
        row, col = @pos

        case @color
        when "white"
            return true if row == 1
        when "black"
            return true if row == 6
        end
    end


    def forward_dir
        case @color
        when "white"
            return 1
        when "black"
            return -1
        end
    end


    def forward_steps
        forward_dir if at_start_row 
    end

end


# p1 = Pawn.new
# p1.move