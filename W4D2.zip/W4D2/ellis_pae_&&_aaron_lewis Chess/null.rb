require_relative "piece.rb"
class NullPiece < Piece
    attr_reader :color, :board, :pos
    def initialize(color, board, pos)
        super
    end
end