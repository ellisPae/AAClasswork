class King < SteppingPiece
end