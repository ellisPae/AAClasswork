class Queen < Piece




end