class Bishop < Piece
    def initialize(color, board, pos)
        super
    end

end
