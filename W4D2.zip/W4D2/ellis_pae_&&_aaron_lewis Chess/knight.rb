class Knight < SteppingPiece
end