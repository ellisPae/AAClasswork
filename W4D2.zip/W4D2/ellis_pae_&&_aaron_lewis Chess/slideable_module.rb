module Slideable
    HORTS_AND_VERTS_DIRS = [[1,0],
    [-1,0],
    [0,1],
    [0,-1]]
    DIAGONAL_DIRS = [[1,1],
    [-1,1],
    [-1,-1],
    [1,-1]]

    def horizontal 
        HORTS_AND_VERTS_DIRS
    end

    def diagonal 
        DIAGONAL_DIRS
    end

    private



    def move_hv
        final_moves = []
        HORTS_AND_VERTS_DIRS.each do |move|
            x, y = move
            final_moves << grow_unblocked_moves_in_dir(x, y)
        end
        final_moves
    end


    def move_diag
        final_moves = []
        DIAGONAL_DIRS.each do |move|
            x, y = move
            final_moves << grow_unblocked_moves_in_dir(x, y)
        end
        final_moves
    end


    
    def grow_unblocked_moves_in_dir(x, y)
        a, b = @pos
        moves_list = []
        loop do
            a += x
            b += y
            possible = [a, b]
            break if @board[possible].color == self.color
            if @board[possible].is_a?(NullPiece)
                moves_list << possible
            else
                moves_list << possible
                break
            end
        end
        moves_list    
    end  
end 
