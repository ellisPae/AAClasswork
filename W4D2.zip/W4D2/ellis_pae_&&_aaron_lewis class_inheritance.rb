class Employee 
    attr_reader :salary, :boss
    attr_accessor :emp_salary

    def initialize(name, title, salary, boss = nil, emp_salary = 0)
        @name = name
        @title = title 
        @salary = salary 
        @boss = boss
        self.have_boss if !boss.nil?
        @emp_salary = emp_salary
    end

    def bonus(multiplier)
        self.salary * multiplier
    end

    def have_boss
        @boss.employees << self
        @boss.emp_salary += self.salary
    end
end

class Manager < Employee

    attr_reader :employees
    attr_accessor :emp_salary

    def initialize (name, title, salary, boss = nil, emp_salary = 0) 
        super
        @employees = []
    end

    def bonus(multiplier)
        total = 0
        @employees.each { |emp| total += (emp.salary + emp.emp_salary) }
        total * multiplier
    end
end


ned = Manager.new("Ned","senior",1000000)
darren = Manager.new("darren","senior",78000,ned)
david = Employee.new("david","senior",10000,darren)
shawna = Employee.new("shawna","senior",12000,darren)
# ned = Employee.new("bob","senior",1,nil)
p ned.bonus(5) # => 500_000
p darren.bonus(4) # => 88_000
p david.bonus(3) # => 30_000