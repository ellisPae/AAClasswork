# == Schema Information
#
# Table name: shortened_urls
#
#  id         :bigint           not null, primary key
#  long_url   :string           not null
#  short_url  :string           not null
#  user_id    :string           not null
#  created_at :datetime         not null
#  updated_at :datetime         not null
#
class ShortenedUrl < ApplicationRecord
    validates :long_url, :short_url, :user_id, presence: true
    validates :short_url, uniqueness: true


    belongs_to :submitters,
        primary_key: :id,
        foreign_key: :user_id,
        class_name: :User
    
    has_many :visits,
        class_name: :Visit,
        primary_key: :id,
        foreign_key: :shortened_url_id,
    

    has_many :visitors,
        through: :visits,
        source: :visitor

    

    def self.random_code
        loop do
            random_url =  SecureRandom.urlsafe_base64(16)
            random_url unless ShortenedUrl.exists?(short_url: random_url)
        end
    end


    def self.create_short_url_for_user!(user, long_url)
        ShortenedUrl.create!(
            long_url: long_url, 
            short_url: ShortenedUrl.random_code, 
            user_id: user.id) 
    end


    def num_clicks
        visits.count
    end


end
