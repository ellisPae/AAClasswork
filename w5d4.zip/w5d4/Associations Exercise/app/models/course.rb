class Course < ApplicationRecord
    # validate :name, :prereq_id, :instructor_id, presence: true
    # validate :name, uniqueness: true

    has_many :enrollments,
        primary_key: :id,
        foreign_key: :course_id,
        class_name: :enrollments

    has_many :users,
        through: :enrollments,
        source: :user


    belongs_to :instructor,
        primary_key: :id,
        foreign_key: :instructor_id,
        class_name: :User


    belongs_to :prereq,
        primary_key: :id,
        foreign_key: :prereq_id,
        class_name: :Course,
        optional: true


end
