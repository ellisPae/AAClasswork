require_relative "piece.rb"

class Pawn < Piece

    attr_reader :color, :board, :pos

    def initialize(color, board, pos)
        super
    end

    def symbol
        '♙'
        # .colorize(color)
    end
    

    def move
        final = forward_step.concat(side_attacks)
        final.select { |move| @board.valid_pos?(move)}
    end



    private

    def at_start_row?
        row, col = @pos
        case @color
        when "white"
            return true if row == 1
        when "black"
            return true if row == 6
        end
    end


    def forward_dir
        case @color
        when "white"
            return 1
        when "black"
            return -1
        end
    end


    def forward_step
        moves = []
        a, b = @pos
        step_1 = [a + forward_dir, b ]
         moves << step_1 if @board[step_1].is_a?(NullPiece)
        if at_start_row?
            x = forward_dir + forward_dir
            step_2 =  [a + x, b]
            moves << step_2 if @board[step_1].is_a?(NullPiece)
        end
        moves
    end

    def side_attacks
        moves = []
        a, b = @pos
        attack_1 = [a + forward_dir, b - 1 ]   
        attack_2 = [a + forward_dir, b + 1 ]
        if @board.valid_pos?(attack_1)
            moves << attack_1 if (@board[attack_1].color != self.color) && !@board[attack_1].is_a?(NullPiece)
        end
        if @board.valid_pos?(attack_2)
             moves << attack_2 if (@board[attack_2].color != self.color) && !@board[attack_2].is_a?(NullPiece)
        end
        moves
    end
            
            

       


end


# p1 = Pawn.new
# p1.move