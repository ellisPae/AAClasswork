require_relative "piece.rb"
require_relative "stepable_module.rb"

class King < Piece
     include Stepable

    attr_reader :color, :board, :pos
    
    def initialize(color, board, pos)
        super
    end

    def symbol
        '♔' #.colorize(color)
    end

    protected

    def move
        move_king
    end
end