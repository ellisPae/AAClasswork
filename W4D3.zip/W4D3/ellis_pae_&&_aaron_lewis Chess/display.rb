# require_relative "colorize"
require_relative "cursor.rb"
require_relative "board.rb"


class Display
    
    attr_reader :board, :cursor
    
    def initialize(board)
        @board = board
        @cursor = Cursor.new([0,0], board)
    end

   
            
    def render
        @board.grid.each do |row|
            arr = []
            row.each do |ele|
                arr << ele.symbol
            end
            puts arr.join(" ")
        end
    end
end
board = Board.new
board.populate
disp = Display.new(board)
disp.render
pos = [1,0]
end_pos = [3,0]
board.move_piece("white",pos,end_pos)
disp.render
