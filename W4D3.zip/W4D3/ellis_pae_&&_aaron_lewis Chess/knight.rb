require_relative "piece.rb"
require_relative "stepable_module.rb"

class Knight < Piece
     include Stepable

        attr_reader :color, :board, :pos
    
        def initialize(color, board, pos)
            super
        end
        

        def symbol
            '♘' #.colorize(color)
        end


        protected

    def move
        move_knight
    end
end
