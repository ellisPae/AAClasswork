require_relative "pieces_call.rb"

class Board

    attr_reader :grid

    def populate 
       pop_white_pawns
       pop_black_pawns
       pop_black_royals
       pop_white_royals
    end

    def add_piece(piece, pos)
        self[pos] = piece
    end 
    
    def initialize
        @sentinel = NullPiece.instance
        @grid = Array.new(8) {Array.new(8, sentinel)}
    end 

    def [](pos)
        row, col = pos
        @grid[row][col]
    end

    def []=(pos, val)
        row, col = pos
        @grid[row][col] = val
    end

    def move_piece(color, start_pos, end_pos)
       raise "off the grid" if !valid_pos?(end_pos)
       raise "this piece cant go there" if !self[start_pos].valid_moves.include?(end_pos)
        piece = self[start_pos]
        self[start_pos] = sentinel
        self[end_pos] = piece
    end

    def valid_pos?(pos)
        row, col = pos
        return false if row < 0 || row > 7
        return false if col < 0 || col > 7
        true
    end


    def pop_black_pawns
         (6..6).each do |i|
            (0..7).each do |j|
                pos = [i,j]
                add_piece(Pawn.new("black", self, pos),pos)
            end
        end
    end
              
    
    def pop_black_royals
        (7..7).each do |i|
            (0..7).each do |j|
                pos = [i,j]
                                   
                add_piece(Rook.new("black", self, pos),pos) if j == 0 || j == 7
                
                add_piece(Knight.new("black", self, pos),pos) if j == 1 || j == 6
                    
                add_piece(Bishop.new("black", self, pos),pos) if j == 2 || j == 5
                    
                add_piece(Queen.new("black", self, pos),pos) if j == 3
                   
                add_piece(King.new("black", self, pos),pos) if j == 4
            end
        end
    end
        



    def pop_white_pawns
        (1..1).each do |i|
            (0..7).each do |j|
                pos = [i,j]
                add_piece(Pawn.new("white", self, pos),pos)
            end
        end
    end

    def pop_white_royals 
        (0..0).each do |i|
            (0..7).each do |j|
                pos = [i,j]
               
                add_piece(Rook.new("white", self, pos),pos) if j == 0 || j == 7
                
                add_piece(Knight.new("white", self, pos),pos) if j == 1 || j == 6
                    
                add_piece(Bishop.new("white", self, pos),pos) if j == 2 || j == 5
                    
                add_piece(Queen.new("white", self, pos),pos) if j == 3
                   
                add_piece(King.new("white", self, pos),pos) if j == 4
        
            end
        end
    end

    

    private

    attr_reader :sentinel



end


# game = Board.new
# game.populate

# puts game[[7, 1]]
# puts "-----------"
# puts game[[7, 7]]











