module Stepable
    KING_MOVES = [[0,1],
    [0,-1],
    [1,0],
    [-1,0],
    [1,1],
    [-1,-1],
    [1,-1],
    [-1,1],
    ]
    KNIGHT_MOVES = [[1,2],
    [1,-2],
    [-1,2],
    [-1,-2],
    [2,1],
    [2,-1],
    [-2,1],
    [-2,-1]
    ]

    def move_king
        moves = []
        KING_MOVES.each do |move|
            a, b = @pos
            x, y = move
            possible = [a + x, b + y]

            moves << possible if @board.valid_pos?(possible) && 
            (@board[possible].is_a?(NullPiece) ||
             @board[possible].color != self.color)
        end
        moves
    end


    def move_knight
        moves = []
        KNIGHT_MOVES.each do |move|
            a, b = @pos 
            x, y = move 
            possible = [a + x, b + y]
            
            moves << possible if @board.valid_pos?(possible) && 
            (@board[possible].is_a?(NullPiece) ||
             @board[possible].color != self.color)
        end
        moves
    end
end