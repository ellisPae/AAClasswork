class Artwork < ApplicationRecord
    validates :title, :image_url, presence: true
    validates :image_url, uniqueness: true
    validates :title, uniqueness: {scope: :artist_id}

    # 1 user cannot have 2 artworks of the same title
    # 2 diff users can have artworks with the same title

    # => 2 sep artists could have artworks named the same thing
    # but a single artist should not be bale to have 2 pieces with the same title
    

    belongs_to :artist,
        class_name: :User,
        primary_key: :id,
        foreign_key: :artist_id

    
    has_many :artwork_shares,
        class_name: :ArtworkShare,
        primary_key: :id,
        foreign_key: :artwork_id
    

    has_many :shared_viewers,
        through: :artwork_shares,
        source: :viewer


    has_many :comments,
        class_name: :Comment,
        primary_key: :id,
        foreign_key: :artwork_id,
        dependent: :destroy


    has_many :likes, as: :likeable

    has_many :likers,
        through: :likes,
        source: :user


end