class CreateArtworks < ActiveRecord::Migration[5.2]
  def change
    create_table :artworks do |t|
      t.string :title, null: false
      t.string :image_url, null: false
      t.integer :artist_id, null: false
      
      t.timestamps
    end
    add_index :artworks, :artist_id
    add_index :artworks, :image_url, unique: true
    add_index :artworks, [:title, :artist_id], unique: true
  end
end

# 1 user cannot have 2 artworks of the same title
# 2 diff users can have artworks with the same title

# => 2 sep artists could have artworks named the same thing
# but a single artist should not be bale to have 2 pieces with the same title