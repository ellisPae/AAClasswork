# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)


User.destroy_all
Artwork.destroy_all
ArtworkShare.destroy_all
Comment.destroy_all

user1 = User.create!(username: 'Rav') 
user2 = User.create!(username: 'Ellis')
user3 = User.create!(username: 'Ara_C')
user4 = User.create!(username: 'Rich_L')
user5 = User.create!(username: 'Josh')
user6 = User.create!(username: 'Paloma')


a1 = Artwork.create!(
    title: 'Mona Lisa', 
    image_url: 'https://upload.wikimedia.org/wikipedia/commons/6/6a/Mona_Lisa.jpg',
    artist_id: user1.id
)


a2 = Artwork.create!(
    title: 'Super Ramen Bot',
    image_url: 'https://www.pinterest.com/pin/822821794406932739/',
    artist_id: user2.id
)


as1 = ArtworkShare.create!(artwork_id: a1.id, viewer_id: user5.id)
as1 = ArtworkShare.create!(artwork_id: a2.id, viewer_id: user6.id)


comment1 = Comment.create!(
    body: 'Eh... I dont get the hype',
    user_id: user4.id,
    artwork_id: a1.id
)

comment2 = Comment.create!(
    body: 'that shit be the maad noise!',
    user_id: user3.id,
    artwork_id: a2.id
)

